import { Product } from "../models/Schema.js";

// 1. Mendapatkan semua produk
export const getProducts = async (req, res) => {
  try {
    const products = await Product.find();
    return res.status(200).json(products);
  } catch (error) {
    console.error("Error getProducts:", error.message);
    return res.status(500).json({ message: error.message });
  }
};

// 2. Menambahkan produk baru (untuk Admin)
export const addProduct = async (req, res) => {
  try {
    console.log("Menerima request addProduct:", req.body);

    const { title, description, price, category, imageUrl, mainImg } = req.body;

    const newProduct = new Product({
      title,
      description,
      price: Number(price),
      category,
      mainImg: mainImg || imageUrl || "",
      imageUrl: imageUrl || mainImg || ""
    });

    const savedProduct = await newProduct.save();
    console.log("SUKSES simpan produk ke DB:", savedProduct);
    
    return res.status(201).json(savedProduct);
  } catch (error) {
    console.error("GAGAL simpan produk:", error.message);
    return res.status(400).json({ message: error.message });
  }
};