import { Cart, Orders } from "../models/Schema.js";

// --- CART CONTROLLERS ---

// 1. Menambahkan produk ke Cart
export const addToCart = async (req, res) => {
  try {
    const cartItem = new Cart(req.body);
    const savedItem = await cartItem.save();
    res.status(201).json({ message: "Product added to cart", savedItem });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 2. Mendapatkan isi Cart berdasarkan userId
export const getCartByUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const cartItems = await Cart.find({ userId });
    res.status(200).json(cartItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 3. Menghapus item dari Cart
export const removeFromCart = async (req, res) => {
  try {
    const { id } = req.params;
    await Cart.findByIdAndDelete(id);
    res.status(200).json({ message: "Item removed from cart" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// --- ORDERS CONTROLLERS ---

// 4. Membuat Pesanan Baru (Checkout / Buy)
export const createOrder = async (req, res) => {
  try {
    console.log("--- PROSES CHECKOUT ---");
    console.log("User ID yang diterima dari frontend:", req.body.userId);

    const newOrder = new Orders(req.body);
    const savedOrder = await newOrder.save();

    if (req.body.userId) {
      // Ubah jadi String untuk memastikan kecocokan tipe data
      const deleteResult = await Cart.deleteMany({ userId: String(req.body.userId) });
      console.log("Hasil hapus Cart di DB:", deleteResult);
    }

    res.status(201).json({ message: "Order placed successfully", savedOrder });
  } catch (error) {
    console.error("Error di createOrder:", error.message);
    res.status(500).json({ message: error.message });
  }
};

// 5. Mendapatkan riwayat Orders berdasarkan userId
export const getOrdersByUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const orders = await Orders.find({ userId });
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 6. Mendapatkan semua Orders (Khusus Admin)
export const getAllOrders = async (req, res) => {
  try {
    const orders = await Orders.find();
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};