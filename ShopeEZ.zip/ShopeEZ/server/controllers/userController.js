import { User } from "../models/Schema.js";

// 1. Registrasi User Baru
export const registerUser = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    // Cek apakah email sudah terdaftar
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already registered" });
    }

    // Tentukan usertype otomatis berdasarkan username khusus
    const assignedUserType = (username.trim() === "adminShopEZ") ? "admin" : "Customer";

    const newUser = new User({ 
      username, 
      email, 
      password, 
      usertype: assignedUserType 
    });
    
    const savedUser = await newUser.save();
    
    res.status(201).json({
      message: "Registration successful",
      userId: savedUser._id,
      username: savedUser.username,
      email: savedUser.email,
      usertype: savedUser.usertype
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 2. Login User
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Validasi password sederhana sesuai blueprint
    if (user.password !== password) {
      return res.status(400).json({ message: "Invalid password" });
    }

    res.status(200).json({
      message: "Login successful",
      userId: user._id,
      username: user.username,
      email: user.email,
      usertype: user.usertype
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};