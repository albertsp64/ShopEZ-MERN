import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());

const PORT = 3001;
const MongoUri = "mongodb://127.0.0.1:27017/shopez_db";

async function startServer() {
  try {
    // 1. Tunggu koneksi database benar-benar CONNECTED 100%
    await mongoose.connect(MongoUri);
    console.log("SUCCESS: Connected to MongoDB database!");

    // 2. BARU import routes & models secara dinamis setelah koneksi siap.
    // Ini menjamin mongoose.model() terpanggil SETELAH database terkoneksi.
    const productRoutes = (await import("./routes/productRoutes.js")).default;
    const userRoutes = (await import("./routes/userRoutes.js")).default;
    const cartOrderRoutes = (await import("./routes/cartOrderRoutes.js")).default;

    // Pasang rute Express
    app.use("/api/products", productRoutes);
    app.use("/api/users", userRoutes);
    app.use("/api/cartorders", cartOrderRoutes);

    // 3. Nyalakan server Express
    app.listen(PORT, () => {
      console.log(`SUCCESS: App server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error("ERROR connecting to Database:", error.message);
  }
}

startServer();