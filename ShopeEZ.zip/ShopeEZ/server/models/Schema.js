import mongoose from "mongoose";

// 1. User Schema
const userSchema = new mongoose.Schema({
  username: { type: String },
  password: { type: String },
  email: { type: String, unique: true },
  usertype: { type: String, default: "Customer" }
});

// 2. Admin Schema
const adminSchema = new mongoose.Schema({
  banner: { type: String },
  categories: { type: Array }
});

// 3. Product Schema
const productSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  mainImg: { type: String },
  imageUrl: { type: String },
  carousel: { type: Array },
  sizes: { type: Array },
  category: { type: String },
  gender: { type: String },
  price: { type: Number, required: true },
  discount: { type: Number, default: 0 }
}, { bufferCommands: false });

// 4. Orders Schema
const orderSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  items: { type: Array },           // <-- TAMBAHKAN INI agar array cartItems tersimpan
  totalAmount: { type: Number },    // <-- TAMBAHKAN INI agar total harga tersimpan
  name: { type: String },
  email: { type: String },
  mobile: { type: String },
  address: { type: String },
  pincode: { type: String },
  title: { type: String },
  description: { type: String },
  mainImg: { type: String },
  size: { type: String },
  quantity: { type: Number },
  price: { type: Number },
  discount: { type: Number },
  paymentMethod: { type: String },
  orderDate: { type: String },
  deliveryDate: { type: String },
  orderStatus: { type: String, default: "order placed" }
});

// 5. Cart Schema
const cartSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  title: { type: String },
  description: { type: String },
  mainImg: { type: String },
  size: { type: String },
  quantity: { type: String },
  price: { type: Number },
  discount: { type: Number }
});

// Export Models
export const User = mongoose.model("users", userSchema);
export const Admin = mongoose.model("admin", adminSchema);
export const Product = mongoose.model("products", productSchema);
export const Orders = mongoose.model("orders", orderSchema);
export const Cart = mongoose.model("cart", cartSchema);