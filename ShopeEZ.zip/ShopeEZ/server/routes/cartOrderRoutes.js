import express from "express";
import { 
  addToCart, 
  getCartByUser, 
  removeFromCart, 
  createOrder, 
  getOrdersByUser, 
  getAllOrders 
} from "../controllers/cartOrderController.js";

const router = express.Router();

// Routes Cart
router.post("/addtocart", addToCart);
router.get("/getcart/:userId", getCartByUser);
router.delete("/removefromcart/:id", removeFromCart);

// Routes Orders
router.post("/createorder", createOrder);
router.get("/getorders/:userId", getOrdersByUser);
router.get("/getallorders", getAllOrders);

export default router;