import express from "express";
import { getProducts, addProduct } from "../controllers/productController.js";

const router = express.Router();

router.get("/getproducts", getProducts);
router.post("/addproduct", addProduct);

export default router;