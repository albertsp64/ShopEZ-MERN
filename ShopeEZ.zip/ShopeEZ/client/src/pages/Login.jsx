import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3001/api/users/login", {
        email,
        password,
      });
      alert("Login Berhasil!");

      // Gabungkan data dari respon backend dengan email input
      const userData = {
        ...res.data,
        email: email, // Menyimpan email ke objek user di localStorage
      };

      localStorage.setItem("user", JSON.stringify(userData));
      navigate("/profile");
    } catch (err) {
      alert("Login Gagal: " + (err.response?.data?.message || err.message));
    }
  };

  return (
    <div style={{ maxWidth: "400px", margin: "3rem auto", padding: "2rem", border: "1px solid #ddd", borderRadius: "8px", background: "#fff" }}>
      <h2>Login ke ShopEZ</h2>
      <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "1rem", marginTop: "1rem" }}>
        <div>
          <label style={{ display: "block", marginBottom: "0.5rem" }}>Email</label>
          <input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required
            style={{ width: "100%", padding: "0.5rem", borderRadius: "4px", border: "1px solid #ccc" }}
          />
        </div>
        <div>
          <label style={{ display: "block", marginBottom: "0.5rem" }}>Password</label>
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required
            style={{ width: "100%", padding: "0.5rem", borderRadius: "4px", border: "1px solid #ccc" }}
          />
        </div>
        <button type="submit" style={{ background: "#e55039", color: "#fff", padding: "0.75rem", border: "none", borderRadius: "4px", cursor: "pointer", fontWeight: "bold" }}>
          Login
        </button>
      </form>
      <p style={{ marginTop: "1rem", textAlign: "center", fontSize: "0.9rem" }}>
        Belum punya akun? <Link to="/register" style={{ color: "#4a69bd" }}>Register di sini</Link>
      </p>
    </div>
  );
}