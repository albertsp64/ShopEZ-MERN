import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Cart() {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchCart = async () => {
    try {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        setLoading(false);
        return;
      }
      const parsedUser = JSON.parse(storedUser);
      const userId = parsedUser.userId || parsedUser._id || parsedUser.id;

      const res = await axios.get(`http://localhost:3001/api/cartorders/getcart/${userId}`);
      setCartItems(res.data.items || res.data || []);
    } catch (err) {
      console.error("Gagal mengambil keranjang:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCart();
  }, []);

  const handleRemoveItem = async (cartItemId) => {
    try {
      await axios.delete(`http://localhost:3001/api/cartorders/removefromcart/${cartItemId}`);
      setCartItems(cartItems.filter(item => item._id !== cartItemId));
    } catch (err) {
      console.error("Gagal menghapus item:", err);
      alert("Gagal menghapus produk dari keranjang.");
    }
  };

  const totalAmount = cartItems.reduce((acc, item) => acc + ((item.price || 0) * (item.quantity || 1)), 0);

  const handleCheckout = async () => {
    try {
      const storedUser = localStorage.getItem("user");
      if (!storedUser) {
        alert("Silakan login terlebih dahulu untuk checkout!");
        navigate("/login");
        return;
      }
      const parsedUser = JSON.parse(storedUser);
      const userId = parsedUser.userId || parsedUser._id || parsedUser.id;

      if (cartItems.length === 0) {
        alert("Keranjang kamu masih kosong!");
        return;
      }

      const orderData = {
        userId: userId,
        items: cartItems,
        totalAmount: totalAmount,
        orderStatus: "Processing"
      };

      await axios.post("http://localhost:3001/api/cartorders/createorder", orderData);

      alert("Checkout berhasil! Pesanan telah dicatat.");
      setCartItems([]);
      navigate("/profile"); 
    } catch (err) {
      console.error("Gagal checkout:", err);
      alert("Checkout gagal: " + (err.response?.data?.message || err.message));
    }
  };

  return (
    <div style={{ maxWidth: "800px", margin: "3rem auto", padding: "2rem" }}>
      {/* Kotak Utama Keranjang */}
      <div style={{ background: "#fff", borderRadius: "8px", border: "1px solid #ddd", padding: "2rem", marginBottom: "1.5rem" }}>
        <h2 style={{ color: "#574B41", marginBottom: "1.5rem" }}>Keranjang Belanja Anda</h2>
        
        {loading ? (
          <p>Memuat keranjang...</p>
        ) : cartItems.length === 0 ? (
          <div style={{ textAlign: "center", padding: "2rem 0" }}>
            <p style={{ color: "#666", fontStyle: "italic", marginBottom: "1rem" }}>Belum ada produk di dalam keranjang.</p>
            <button 
              onClick={() => navigate("/products")}
              style={{ backgroundColor: "#574B41", color: "#E7DAC6", padding: "0.6rem 1.2rem", border: "none", borderRadius: "6px", fontWeight: "bold", cursor: "pointer" }}
            >
              Belanja Sekarang
            </button>
          </div>
        ) : (
          <div>
            <div style={{ display: "flex", flexDirection: "column", gap: "1rem", marginBottom: "2rem" }}>
              {cartItems.map((item, index) => (
                <div 
                  key={item._id || index} 
                  style={{ display: "flex", justifyContent: "space-between", alignItems: "center", border: "1px solid #C8C4C2", padding: "1rem", borderRadius: "6px", background: "#F8F5F0" }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                    {item.imageUrl && (
                      <img src={item.imageUrl} alt={item.title} style={{ width: "60px", height: "60px", objectFit: "cover", borderRadius: "4px" }} />
                    )}
                    <div>
                      <h4 style={{ margin: "0 0 0.3rem 0", color: "#574B41" }}>{item.title || item.name}</h4>
                      <p style={{ margin: 0, color: "#636633", fontWeight: "bold" }}>$ {item.price} x {item.quantity || 1}</p>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleRemoveItem(item._id)}
                    style={{ backgroundColor: "#d9534f", color: "#fff", border: "none", padding: "0.5rem 0.8rem", borderRadius: "4px", cursor: "pointer", fontWeight: "bold", fontSize: "0.85rem" }}
                    title="Hapus produk ini"
                  >
                    Hapus
                  </button>
                </div>
              ))}
            </div>

            {/* Total Harga diposisikan ke tengah (justifyContent: "center") */}
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", borderTop: "2px solid #ddd", paddingTop: "1.5rem" }}>
              <h3 style={{ margin: 0, color: "#574B41" }}>Total: $ {totalAmount}</h3>
            </div>
          </div>
        )}
      </div>

      {/* Tombol Checkout di Luar Kotak Utama */}
      {cartItems.length > 0 && !loading && (
        <div style={{ display: "flex", justifyContent: "center" }}>
          <button 
            onClick={handleCheckout}
            style={{ backgroundColor: "#636633", color: "#ffffff", padding: "0.85rem 2.5rem", border: "none", borderRadius: "6px", fontWeight: "bold", cursor: "pointer", fontSize: "1.1rem", boxShadow: "0 4px 6px rgba(0,0,0,0.1)" }}
          >
            Checkout Sekarang
          </button>
        </div>
      )}
    </div>
  );
}