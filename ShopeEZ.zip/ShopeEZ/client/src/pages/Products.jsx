import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:3001/api/products/getproducts")
      .then((res) => setProducts(res.data))
      .catch((err) => console.error("Error fetching products:", err));
  }, []);

  // Fungsi untuk menangani Add to Cart
  const handleAddToCart = async (product) => {
    try {
      // Ambil data user dari localStorage
      const storedUser = localStorage.getItem("user");
      let userId = "guest_user_id";

      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        // Pengecekan fleksibel untuk userId, _id, atau id
        userId = parsedUser.userId || parsedUser._id || parsedUser.id || "guest_user_id";
      }

      const cartData = {
        userId: userId,
        productId: product._id || product.id,
        title: product.title || product.name,
        price: product.price,
        imageUrl: product.imageUrl || product.image,
        quantity: 1,
      };

      const response = await axios.post(
        "http://localhost:3001/api/cartorders/addtocart",
        cartData
      );

      alert("Produk berhasil ditambahkan ke keranjang!");
      console.log("Cart response:", response.data);
    } catch (error) {
      console.error("Error adding to cart:", error);
      alert(
        "Gagal menambahkan produk ke keranjang: " +
          (error.response?.data?.message || error.message)
      );
    }
  };

  return (
    <div style={{ padding: "2.5rem 2rem" }}>
      <div style={{ marginBottom: "2rem", textAlign: "center" }}>
        <h2 style={{ fontSize: "2rem", color: "#574B41", margin: 0 }}>
          All Products Catalog
        </h2>
        <p style={{ color: "#6B6375", marginTop: "0.5rem" }}>
          Find your favorite items at the best prices.
        </p>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
          gap: "1.8rem",
        }}
      >
        {products.length === 0 ? (
          <p style={{ textAlign: "center", gridColumn: "1 / -1", color: "#6B6375" }}>
            Belum ada produk. Tambahkan produk baru melalui menu <b>Admin</b>!
          </p>
        ) : (
          products.map((item) => (
            <div
              key={item._id}
              style={{
                backgroundColor: "#F8F5F0",
                border: "1px solid #C8C4C2",
                borderRadius: "10px",
                padding: "1.2rem",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
              }}
            >
              <div>
                {item.imageUrl && (
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    style={{
                      width: "100%",
                      height: "160px",
                      objectFit: "cover",
                      borderRadius: "6px",
                      marginBottom: "1rem",
                    }}
                  />
                )}
                <h3 style={{ fontSize: "1.1rem", color: "#574B41", margin: "0 0 0.5rem" }}>
                  {item.title}
                </h3>
                <p style={{ color: "#6B6375", fontSize: "0.9rem", marginBottom: "1rem" }}>
                  {item.description}
                </p>
              </div>

              <div>
                <p
                  style={{
                    fontSize: "1.2rem",
                    fontWeight: "800",
                    color: "#636633",
                    marginBottom: "0.8rem",
                  }}
                >
                  $ {item.price}
                </p>
                <button
                  onClick={() => handleAddToCart(item)}
                  style={{
                    width: "100%",
                    backgroundColor: "#574B41",
                    color: "#E7DAC6",
                    padding: "0.6rem",
                    borderRadius: "6px",
                    fontWeight: "600",
                    cursor: "pointer",
                    border: "none",
                  }}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}