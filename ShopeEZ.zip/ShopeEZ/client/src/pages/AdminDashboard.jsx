import React, { useState, useEffect } from "react";
import axios from "axios";

export default function AdminDashboard() {
  // State untuk Form Tambah Produk
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  // State untuk Daftar Semua Pesanan Masuk
  const [allOrders, setAllOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(true);

  // Ambil semua pesanan saat halaman dimuat
  useEffect(() => {
    const fetchAllOrders = async () => {
      try {
        const res = await axios.get("http://localhost:3001/api/cartorders/getallorders");
        setAllOrders(res.data || []);
      } catch (err) {
        console.error("Gagal mengambil semua pesanan:", err);
      } finally {
        setLoadingOrders(false);
      }
    };

    fetchAllOrders();
  }, []);

  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      const productData = {
        title,
        description,
        price: Number(price),
        category,
        imageUrl,
      };

      await axios.post("http://localhost:3001/api/products/addproduct", productData);
      alert("Produk berhasil ditambahkan ke katalog!");
      
      // Reset form
      setTitle("");
      setDescription("");
      setPrice("");
      setCategory("");
      setImageUrl("");
    } catch (err) {
      console.error("Gagal menambah produk:", err);
      alert("Gagal menambah produk: " + (err.response?.data?.message || err.message));
    }
  };

  // Fungsi helper untuk memformat tanggal dari createdAt atau ObjectId MongoDB
  const formatDate = (order) => {
    let date;
    if (order.createdAt) {
      date = new Date(order.createdAt);
    } else if (order._id && order._id.length === 24) {
      const timestamp = parseInt(order._id.substring(0, 8), 16) * 1000;
      date = new Date(timestamp);
    }
    if (!date || isNaN(date.getTime())) return null;

    return date.toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <div style={{ maxWidth: "900px", margin: "3rem auto", padding: "2rem" }}>
      
      {/* Form Tambah Produk */}
      <div style={{ background: "#fff", padding: "2rem", borderRadius: "8px", border: "1px solid #ddd", marginBottom: "3rem" }}>
        <h2 style={{ color: "#574B41", marginBottom: "1.5rem" }}>Admin Dashboard - Add New Product</h2>
        
        <form onSubmit={handleAddProduct} style={{ display: "flex", flexDirection: "column", gap: "1.2rem" }}>
          <div>
            <label style={{ display: "block", marginBottom: "0.4rem", fontWeight: "600", color: "#574B41" }}>Product Title</label>
            <input 
              type="text" 
              placeholder="e.g. Leather Jacket" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              required
              style={{ width: "100%", padding: "0.75rem", borderRadius: "6px", border: "1px solid #C8C4C2", boxSizing: "border-box" }}
            />
          </div>

          <div>
            <label style={{ display: "block", marginBottom: "0.4rem", fontWeight: "600", color: "#574B41" }}>Description</label>
            <textarea 
              placeholder="Product details and specifications" 
              value={description} 
              onChange={(e) => setDescription(e.target.value)} 
              rows="3"
              style={{ width: "100%", padding: "0.75rem", borderRadius: "6px", border: "1px solid #C8C4C2", boxSizing: "border-box", resize: "vertical" }}
            />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
            <div>
              <label style={{ display: "block", marginBottom: "0.4rem", fontWeight: "600", color: "#574B41" }}>Price ($)</label>
              <input 
                type="number" 
                placeholder="4999" 
                value={price} 
                onChange={(e) => setPrice(e.target.value)} 
                required
                style={{ width: "100%", padding: "0.75rem", borderRadius: "6px", border: "1px solid #C8C4C2", boxSizing: "border-box" }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: "0.4rem", fontWeight: "600", color: "#574B41" }}>Category</label>
              <input 
                type="text" 
                placeholder="e.g. Outerwear" 
                value={category} 
                onChange={(e) => setCategory(e.target.value)} 
                style={{ width: "100%", padding: "0.75rem", borderRadius: "6px", border: "1px solid #C8C4C2", boxSizing: "border-box" }}
              />
            </div>
          </div>

          <div>
            <label style={{ display: "block", marginBottom: "0.4rem", fontWeight: "600", color: "#574B41" }}>Product Image URL</label>
            <input 
              type="text" 
              placeholder="https://example.com/image.jpg" 
              value={imageUrl} 
              onChange={(e) => setImageUrl(e.target.value)} 
              style={{ width: "100%", padding: "0.75rem", borderRadius: "6px", border: "1px solid #C8C4C2", boxSizing: "border-box" }}
            />
          </div>

          <button 
            type="submit" 
            style={{ backgroundColor: "#636633", color: "#ffffff", padding: "0.8rem", border: "none", borderRadius: "6px", fontWeight: "bold", cursor: "pointer", fontSize: "1rem", marginTop: "0.5rem" }}
          >
            Add Product
          </button>
        </form>
      </div>

      {/* Daftar Semua Pesanan Masuk (Admin View) */}
      <div style={{ background: "#fff", padding: "2rem", borderRadius: "8px", border: "1px solid #ddd" }}>
        <h2 style={{ color: "#574B41", marginBottom: "1.5rem" }}>Semua Pesanan Masuk (Admin Orders)</h2>
        
        {loadingOrders ? (
          <p>Memuat daftar pesanan...</p>
        ) : allOrders.length === 0 ? (
          <p style={{ color: "#666", fontStyle: "italic" }}>Belum ada pesanan yang masuk dari pengguna.</p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            {allOrders.map((order, index) => {
              const formattedDate = formatDate(order);

              // Menangkap berbagai kemungkinan nama array items dari data lama/baru
              let itemList = order.items || order.products || order.cartItems || [];
              
              // Fallback untuk data order format lama tanpa array items
              if (itemList.length === 0 && (order.title || order.name || order.productTitle)) {
                itemList = [{
                  title: order.title || order.name || order.productTitle,
                  price: order.price || 0,
                  quantity: order.quantity || 1
                }];
              }

              // Kalkulasi total harga otomatis
              let total = order.totalAmount ?? order.totalPrice ?? order.total;
              if (total === undefined || total === null || total === 0) {
                total = itemList.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 1)), 0);
              }

              return (
                <div key={order._id || index} style={{ border: "1px solid #C8C4C2", padding: "1.2rem", borderRadius: "8px", background: "#F8F5F0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.8rem", borderBottom: "1px solid #dcd6cd", paddingBottom: "0.6rem", flexWrap: "wrap", gap: "0.5rem" }}>
                    <div>
                      <strong style={{ fontSize: "0.9rem" }}>User ID:</strong> <span style={{ fontFamily: "monospace", fontSize: "0.85rem" }}>{order.userId || "Guest"}</span>
                    </div>

                    {/* Tanggal Pesanan & Status */}
                    <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                      {formattedDate && (
                        <span style={{ fontSize: "0.85rem", color: "#666", fontStyle: "italic" }}>
                          📅 {formattedDate}
                        </span>
                      )}
                      <span style={{ backgroundColor: "#e2eddc", color: "#27ae60", padding: "0.2rem 0.6rem", borderRadius: "4px", fontWeight: "bold", fontSize: "0.85rem" }}>
                        {order.orderStatus || order.status || "Processing"}
                      </span>
                    </div>
                  </div>

                  {/* Daftar Items */}
                  {itemList.length > 0 ? (
                    <div style={{ margin: "0.6rem 0" }}>
                      <p style={{ margin: "0 0 0.4rem 0", fontWeight: "600", color: "#574B41", fontSize: "0.95rem" }}>Produk Dipesan:</p>
                      <ul style={{ margin: 0, paddingLeft: "1.2rem", color: "#444" }}>
                        {itemList.map((item, idx) => (
                          <li key={idx} style={{ marginBottom: "0.3rem", fontSize: "0.95rem" }}>
                            {item.title || item.name || item.productTitle || "Produk"} — {item.quantity || 1}x @ $ {item.price || 0}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : (
                    <p style={{ fontStyle: "italic", color: "#888", fontSize: "0.9rem", margin: "0.5rem 0" }}>Detail item tidak tersedia.</p>
                  )}

                  <div style={{ textAlign: "right", marginTop: "0.8rem", borderTop: "1px dashed #dcd6cd", paddingTop: "0.6rem" }}>
                    <span style={{ fontWeight: "bold", color: "#574B41", fontSize: "1rem" }}>
                      Total Pendapatan Order: $ {total}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}