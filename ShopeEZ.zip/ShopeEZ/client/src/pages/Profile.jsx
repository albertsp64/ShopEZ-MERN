import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      navigate("/login");
      return;
    }
    const parsedUser = JSON.parse(storedUser);
    setUser(parsedUser);

    const fetchOrders = async () => {
      try {
        const userId = parsedUser.userId || parsedUser._id || parsedUser.id;
        const res = await axios.get(`http://localhost:3001/api/cartorders/getorders/${userId}`);
        setOrders(res.data);
      } catch (err) {
        console.error("Gagal mengambil riwayat pesanan:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    alert("Berhasil Logout!");
    navigate("/login");
  };

  // Fungsi untuk mengambil tanggal dari createdAt atau langsung dari timestamp _id MongoDB
  const formatDate = (order) => {
    let date;

    if (order.createdAt) {
      date = new Date(order.createdAt);
    } else if (order._id && order._id.length === 24) {
      const timestamp = parseInt(order._id.substring(0, 8), 16) * 1000;
      date = new Date(timestamp);
    }

    if (!date || isNaN(date.getTime())) return "Tanggal tidak tersedia";

    return date.toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  if (!user) return null;

  return (
    <div style={{ maxWidth: "800px", margin: "3rem auto", padding: "2rem", background: "#fff", borderRadius: "8px", border: "1px solid #ddd" }}>
      <h2 style={{ color: "#574B41", marginBottom: "1rem" }}>Profil Pengguna</h2>
      
      {/* Informasi Akun */}
      <div style={{ marginBottom: "2rem", background: "#F8F5F0", padding: "1.5rem", borderRadius: "6px", border: "1px solid #C8C4C2" }}>
        <p style={{ marginBottom: "0.5rem" }}><strong>Username:</strong> {user.username || user.name}</p>
        <p style={{ marginBottom: "0.5rem" }}><strong>Email:</strong> {user.email || "-"}</p>
        <p style={{ marginBottom: "1rem", wordBreak: "break-all" }}><strong>User ID:</strong> {user.userId || user._id || user.id}</p>
        <button 
          onClick={handleLogout} 
          style={{ background: "#e55039", color: "#fff", border: "none", padding: "0.6rem 1.2rem", borderRadius: "4px", cursor: "pointer", fontWeight: "bold" }}
        >
          Logout
        </button>
      </div>

      {/* Riwayat Pesanan */}
      <h3 style={{ color: "#574B41", marginBottom: "1rem" }}>Riwayat Pesanan (Order History)</h3>
      {loading ? (
        <p>Memuat riwayat pesanan...</p>
      ) : orders.length === 0 ? (
        <p style={{ color: "#666", fontStyle: "italic" }}>Belum ada pesanan yang dilakukan.</p>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          {orders.map((order, index) => {
            const formattedDate = formatDate(order);

            return (
              <div key={order._id || index} style={{ border: "1px solid #C8C4C2", padding: "1.2rem", borderRadius: "8px", background: "#F8F5F0" }}>
                
                {/* Header Kartu: Order ID & Tanggal Pemesanan */}
                <div style={{ borderBottom: "1px solid #dcd6cd", paddingBottom: "0.8rem", marginBottom: "0.8rem", textAlign: "center" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.5rem", flexWrap: "wrap", gap: "0.5rem" }}>
                    <div style={{ textAlign: "left", wordBreak: "break-all" }}>
                      <strong>Order ID:</strong> <span style={{ fontFamily: "monospace", fontSize: "0.85rem" }}>{order._id}</span>
                    </div>

                    {/* Tanggal Pemesanan */}
                    <span style={{ fontSize: "0.85rem", color: "#666", fontStyle: "italic" }}>
                      📅 {formattedDate}
                    </span>
                  </div>

                  {/* Status Pesanan */}
                  <div style={{ display: "inline-block", backgroundColor: "#e2eddc", color: "#27ae60", padding: "0.3rem 1.2rem", borderRadius: "20px", fontWeight: "bold", fontSize: "0.9rem" }}>
                    {order.orderStatus || "Processing"}
                  </div>
                </div>
                
                {/* Detail Items */}
                {order.items && order.items.length > 0 && (
                  <div style={{ margin: "0.6rem 0" }}>
                    <p style={{ margin: "0 0 0.4rem 0", fontWeight: "600", color: "#574B41", fontSize: "0.95rem" }}>Daftar Produk:</p>
                    <ul style={{ margin: 0, paddingLeft: "1.2rem", color: "#444" }}>
                      {order.items.map((item, idx) => (
                        <li key={idx} style={{ marginBottom: "0.3rem", fontSize: "0.95rem" }}>
                          {item.title || item.name || "Produk"} — {item.quantity || 1}x @ $ {item.price || 0}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Total Price */}
                {order.totalAmount !== undefined && (
                  <div style={{ textAlign: "right", marginTop: "0.8rem", borderTop: "1px dashed #dcd6cd", paddingTop: "0.6rem" }}>
                    <span style={{ fontWeight: "bold", color: "#574B41", fontSize: "1rem" }}>
                      Total Harga: $ {order.totalAmount}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}