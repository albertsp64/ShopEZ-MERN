import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div style={{ padding: "3rem 2rem", textAlign: "center" }}>
      {/* Hero Section */}
      <div
        style={{
          backgroundColor: "#E7DAC6",
          padding: "3.5rem 2rem",
          borderRadius: "12px",
          border: "1px solid #C8C4C2",
          maxWidth: "850px",
          margin: "0 auto",
        }}
      >
        <span
          style={{
            backgroundColor: "#574B41",
            color: "#E7DAC6",
            padding: "0.3rem 0.8rem",
            borderRadius: "20px",
            fontSize: "0.8rem",
            fontWeight: "600",
            textTransform: "uppercase",
            letterSpacing: "1px",
          }}
        >
          New Collection 2026
        </span>

        <h1
          style={{
            fontSize: "2.8rem",
            color: "#574B41",
            margin: "1.2rem 0 0.8rem",
            fontWeight: "800",
          }}
        >
          Welcome to ShopEZ
        </h1>

        <p
          style={{
            fontSize: "1.1rem",
            color: "#333333",
            maxWidth: "600px",
            margin: "0 auto 2rem",
            lineHeight: "1.6",
          }}
        >
          Your one-stop destination for effortless online shopping. Explore our handpicked collection with grounded style and quality[cite: 2].
        </p>

        <Link
          to="/products"
          style={{
            display: "inline-block",
            backgroundColor: "#636633",
            color: "#ffffff",
            padding: "0.85rem 2.2rem",
            borderRadius: "8px",
            fontWeight: "700",
            textDecoration: "none",
            boxShadow: "0 4px 12px rgba(99, 102, 51, 0.25)",
            fontSize: "1rem",
          }}
        >
          Explore Catalog
        </Link>
      </div>
    </div>
  );
}