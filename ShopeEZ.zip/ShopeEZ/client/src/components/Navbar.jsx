import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

export default function Navbar() {
  const [user, setUser] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    // Cek status user dari localStorage setiap kali berpindah halaman/rute
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      setUser(null);
    }
  }, [location]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    alert("Berhasil Logout!");
    navigate("/login");
  };

  const getLinkStyle = (path) => ({
    color: location.pathname === path ? "#574B41" : "#333333",
    borderBottom: location.pathname === path ? "2px solid #636633" : "2px solid transparent",
    textDecoration: "none",
    fontWeight: location.pathname === path ? "700" : "500",
    fontSize: "0.95rem",
    paddingBottom: "4px",
    transition: "all 0.2s ease",
  });

  // Pengecekan admin: Hanya muncul jika usertype admin atau username persis "adminShopEZ"
  const isAdmin = user && (user.usertype === "admin" || user.username === "adminShopEZ");

  return (
    <header style={{ width: "100%", borderBottom: "1px solid #C8C4C2" }}>
      {/* Top Banner */}
      <div
        style={{
          backgroundColor: "#574B41",
          color: "#E7DAC6",
          fontSize: "0.8rem",
          textAlign: "center",
          padding: "0.5rem 1rem",
          fontWeight: "500",
          letterSpacing: "0.5px",
        }}
      >
        Welcome to ShopEZ • Enjoy smooth and grounded shopping experience.
      </div>

      {/* Main Nav */}
      <nav
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "1.2rem 2.5rem",
          backgroundColor: "#E7DAC6",
        }}
      >
        {/* Logo */}
        <Link to="/" style={{ textDecoration: "none" }}>
          <h2
            style={{
              margin: 0,
              color: "#574B41",
              fontSize: "1.6rem",
              fontWeight: "800",
              letterSpacing: "1px",
            }}
          >
            Shop<span style={{ color: "#636633" }}>EZ</span>
          </h2>
        </Link>

        {/* Links */}
        <div style={{ display: "flex", gap: "2rem", alignItems: "center" }}>
          <Link to="/" style={getLinkStyle("/")}>
            Home
          </Link>
          <Link to="/products" style={getLinkStyle("/products")}>
            Products
          </Link>
          <Link to="/cart" style={getLinkStyle("/cart")}>
            Cart
          </Link>
          <Link to="/profile" style={getLinkStyle("/profile")}>
            Profile
          </Link>

          {/* Menu Admin HANYA muncul jika kondisi isAdmin bernilai true */}
          {isAdmin && (
            <Link to="/admin" style={getLinkStyle("/admin")}>
              Admin
            </Link>
          )}

          {/* Conditional Rendering: Tombol Login atau Logout */}
          {user ? (
            <button
              onClick={handleLogout}
              style={{
                backgroundColor: "#e55039",
                color: "#ffffff",
                padding: "0.55rem 1.4rem",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                fontWeight: "600",
                fontSize: "0.85rem",
                boxShadow: "0 2px 6px rgba(229, 80, 57, 0.2)",
              }}
            >
              Logout
            </button>
          ) : (
            <Link
              to="/login"
              style={{
                backgroundColor: "#636633",
                color: "#ffffff",
                padding: "0.55rem 1.4rem",
                borderRadius: "6px",
                textDecoration: "none",
                fontWeight: "600",
                fontSize: "0.85rem",
                boxShadow: "0 2px 6px rgba(99, 102, 51, 0.2)",
              }}
            >
              Login
            </Link>
          )}
        </div>
      </nav>
    </header>
  );
}